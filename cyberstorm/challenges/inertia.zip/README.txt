Run 'java Main' at the command line in order to start the game.

If you win the game, you win the challenge; simply show White administrator the screen declaring that you have won.

If you find yourself struggling, perhaps take a moment to -reflect- on the issue at hand.
